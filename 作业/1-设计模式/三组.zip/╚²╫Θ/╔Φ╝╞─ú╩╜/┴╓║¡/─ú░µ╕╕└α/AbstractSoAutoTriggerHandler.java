package com.odianyun.oms.backend.task.order.job.handle.template;

import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.odianyun.common.utils.CollectionUtil;
import com.odianyun.db.mybatis.QueryParam;
import com.odianyun.oms.backend.common.constants.Constant;
import com.odianyun.oms.backend.order.mapper.SoAutoConfigMapper;
import com.odianyun.oms.backend.order.model.po.SoAutoConfigPO;
import com.odianyun.project.support.session.SessionHelper;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @ClassName AbstractSoAutoTriggerHandler
 * @Description 处理订单自动触发的抽象类
 * @Author 林涵
 * @Date 2021/4/19 15:53
 * @Version 2.0
 **/
@Component
public abstract class AbstractSoAutoTriggerHandler<T> {

    @Resource
    private SoAutoConfigMapper soAutoConfigMapper;

    protected final String STORE = "STORE";
    protected final String MERCHANT = "MERCHANT";
    protected final String GLOBAL = "GLOBAL";

    protected final int CANCEL = 0;
    protected final int SIGN = 1;
    protected final int COMPLETE = 2;
    protected final int RETURN_AUDIT = 3;

    // 最小单位为分，说明每分钟都会执行一次job，如果第一次job没有执行完，就开始了第二次job，使用单例会有线程安全问题，所以用ThreadLocal处理
    protected final ThreadLocal<Map<String, List<Long>>> excludeStoreIdsThreadLocal = new ThreadLocal<>();
    protected final ThreadLocal<Map<String, List<Long>>> excludeMerchantIdsThreadLocal = new ThreadLocal<>();

    /**
     * @return java.util.Map<java.lang.String, java.util.List < com.odianyun.oms.backend.order.model.po.SoAutoConfigPO>>
     * @Author linhan
     * @Description 得到某一类型规则根据不同维度进行分组的map，比如得到自动签收规则根据店铺、商家、全局三种维度分组的map
     * @Date 16:07 2021/4/19
     * @Param [q]
     **/
    protected Map<String, List<SoAutoConfigPO>> getSoAutoConfigMap(QueryParam q) {

        SessionHelper.disableFilterMerchantIds();
        SessionHelper.disableFilterStoreIds();
        List<SoAutoConfigPO> list = soAutoConfigMapper.list(q);
        SessionHelper.enableFilterMerchantIds();
        SessionHelper.enableFilterStoreIds();
        //查出来可能等于null?
        list = list == null ? Lists.newArrayList() : list;

        //店铺规则
        final List<SoAutoConfigPO> storeList = list.stream().filter(s -> s.getStoreId() != null).collect(Collectors.toList());
        //商家规则
        final List<SoAutoConfigPO> merchantList = list.stream().filter(s -> s.getStoreId() == null && s.getMerchantId() != null).collect(Collectors.toList());
        //全局规则
        final List<SoAutoConfigPO> globalList = list.stream().filter(s -> s.getStoreId() == null && s.getMerchantId() == null).collect(Collectors.toList());

        final HashMap<String, List<SoAutoConfigPO>> map = Maps.newHashMap();
        map.put(STORE, CollectionUtil.isEmpty(storeList) ? Lists.newArrayList() : storeList);
        map.put(MERCHANT, CollectionUtil.isEmpty(merchantList) ? Lists.newArrayList() : merchantList);
        map.put(GLOBAL, CollectionUtil.isEmpty(merchantList) ? Lists.newArrayList() : globalList);

        // 对店铺规则进行分组，得到已经有规则的店铺ID
        final Map<String, List<Long>> excludeStoreIdsMap = storeList.stream().collect(Collectors.groupingBy(getGroupByOfConditionAboutMerchant(),
                Collectors.mapping(SoAutoConfigPO::getStoreId, Collectors.toList())));
        excludeStoreIdsThreadLocal.set(excludeStoreIdsMap);

        // 对商家规则进行分组，得到已经有规则的商家ID
        final Map<String, List<Long>> excludeMerchantIdsMap = merchantList.stream().collect(Collectors.groupingBy(getGroupByOfCondition(),
                Collectors.mapping(SoAutoConfigPO::getMerchantId, Collectors.toList())));
        excludeMerchantIdsThreadLocal.set(excludeMerchantIdsMap);

        return map;
    }

    /**
     * @return void
     * @Author linhan
     * @Description 实际执行的方法
     * @Date 16:00 2021/4/19
     * @Param []
     **/
    public void doExecute() {
        // 1、获取"订单自动触发规则"，并区分"店铺规则"、"商家规则"、"全局规则"
        final Map<String, List<SoAutoConfigPO>> map = getSoAutoConfigMap(getSoAutoConfigOfCondition());
        // type=STORE、MERCHANT、GLOBAL，keySet这里遍历不一定是有序的
        for (String type : map.keySet()) {
            final List<SoAutoConfigPO> list = map.get(type);
            for (SoAutoConfigPO po : list) {
                // 2、根据"订单自动触发规则"拼接条件
                QueryParam soQ = exclude(getPendingListOfCondition(po), type, po);
                // 3、获取"待处理列表"的"总条数"
                final int total = getPendingListTotalBySoAutoConfigPO(soQ);
                final int limit = Constant.SIZE_500;
                int page = 0;
                // 处理表中前total条，新增的订单不处理
                while (page++ < (total / limit + 1)) {
                    PageHelper.startPage(page, limit, false);
                    // 4、获取"待处理列表"
                    List<T> pendingList = getPendingListBySoAutoConfigPO(soQ);
                    // 5、处理"待处理列表"
                    doHandlePendingList(pendingList);
                }
            }
        }
        // 防止内存溢出和线程池导致的脏数据
        excludeStoreIdsThreadLocal.remove();
        excludeMerchantIdsThreadLocal.remove();
    }

    /**
     * @return com.odianyun.db.mybatis.QueryParam
     * @Author linhan
     * @Description 根据不同维度的规则封装条件
     * @Date 10:25 2021/8/5
     * @Param [soQ, type, po]
     **/
    protected QueryParam exclude(QueryParam soQ, String type, SoAutoConfigPO po) {
        // 处理有店铺规则的订单
        if (STORE.equals(type)) {
            soQ.eq("storeId", po.getStoreId());
        }
        // 处理没有店铺规则，但是有商家规则的订单
        else if (MERCHANT.equals(type)) {
            String key = getGroupByOfConditionAboutMerchant().apply(po);
            List<Long> excludeStoreIds = excludeStoreIdsThreadLocal.get().get(key);
            if (CollectionUtils.isNotEmpty(excludeStoreIds)) {
                // 排除具有店铺规则的订单
                soQ.notIn("storeId", excludeStoreIds);
            }
            soQ.eq("merchantId", po.getMerchantId());
        }
        //匹配既没有店铺规则，也没有商家规则的订单
        else if (GLOBAL.equals(type)) {
            // 排除有店铺规则的订单
            String keyAboutMerchant = getGroupByOfConditionAboutMerchant().apply(po);
            List<Long> excludeStoreIds = excludeStoreIdsThreadLocal.get().get(keyAboutMerchant);
            if (CollectionUtils.isNotEmpty(excludeStoreIds)) {
                soQ.notIn("storeId", excludeStoreIds);
            }

            // 排除有商家规则的订单
            String key = getGroupByOfCondition().apply(po);
            List<Long> excludeMerchantIds = excludeMerchantIdsThreadLocal.get().get(key);
            if (CollectionUtils.isNotEmpty(excludeMerchantIds)) {
                soQ.notIn("merchantId", excludeMerchantIds);
            }
        }
        return soQ;
    }

    /**
     * @return
     * @Author linhan
     * @Description 店铺规则分组方式，在商家规则匹配订单的时候用来排除店铺用的
     * @Date 15:56 2021/4/19
     * @Param
     **/
    protected abstract Function<SoAutoConfigPO, String> getGroupByOfCondition();

    /**
     * @return
     * @Author linhan
     * @Description 店铺规则分组方式，在商家规则匹配订单的时候用来排除店铺用的
     * @Date 15:56 2021/4/19
     * @Param
     **/
    protected abstract Function<SoAutoConfigPO, String> getGroupByOfConditionAboutMerchant();

    /**
     * @return com.odianyun.db.mybatis.QueryParam
     * @Author linhan
     * @Description 获取"订单自动触发规则类型"，如自动取消、自动签收、自动完成、自动售后等
     * @Date 15:56 2021/4/19
     * @Param []
     **/
    protected abstract QueryParam getSoAutoConfigOfCondition();


    /**
     * @return com.odianyun.db.mybatis.QueryParam
     * @Author linhan
     * @Description 根据"订单自动触发规则"拼接条件
     * @Date 15:56 2021/4/19
     * @Param [po, type],type=store or merchant
     **/
    protected abstract QueryParam getPendingListOfCondition(SoAutoConfigPO po);

    /**
     * @return int
     * @Author linhan
     * @Description 获取"待处理列表"的"总条数"
     * @Date 15:57 2021/4/19
     * @Param [soQ]
     **/
    protected abstract int getPendingListTotalBySoAutoConfigPO(QueryParam soQ);

    /**
     * @return java.util.List<T>
     * @Author linhan
     * @Description 获取"待处理列表"
     * @Date 15:57 2021/4/19
     * @Param [soQ]
     **/
    protected abstract List<T> getPendingListBySoAutoConfigPO(QueryParam soQ);

    /**
     * @return void
     * @Author linhan
     * @Description 处理"待处理列表"
     * @Date 15:57 2021/4/19
     * @Param [pendingList]
     **/
    protected abstract void doHandlePendingList(List<T> pendingList);

}
