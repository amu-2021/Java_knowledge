package com.odianyun.oms.backend.task.order.job.handle.template.impl;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.ImmutableList;
import com.odianyun.common.utils.log.LogUtils;
import com.odianyun.db.mybatis.QueryParam;
import com.odianyun.oms.backend.order.constants.OrderStatus;
import com.odianyun.oms.backend.order.constants.ReturnConstant;
import com.odianyun.oms.backend.order.mapper.SoMapper;
import com.odianyun.oms.backend.order.mapper.SoReturnMapper;
import com.odianyun.oms.backend.order.model.po.SoAutoConfigPO;
import com.odianyun.oms.backend.order.model.po.SoPO;
import com.odianyun.oms.backend.order.model.po.SoReturnPO;
import com.odianyun.oms.backend.order.service.OrderStatusService;
import com.odianyun.oms.backend.task.order.job.handle.template.AbstractSoAutoTriggerHandler;
import com.odianyun.project.support.base.db.Q;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @ClassName SoAutoSignHandler
 * @Description 处理订单自动完成
 * @Author 林涵
 * @Date 2021/4/19 15:53
 * @Version 1.0
 **/
@Component
public class SoAutoCompleteHandler extends AbstractSoAutoTriggerHandler<SoPO> {

    private final Logger logger = LogUtils.getLogger(this.getClass());

    @Resource
    private OrderStatusService orderStatusService;

    @Resource
    private SoMapper soMapper;

    @Resource
    private SoReturnMapper soReturnMapper;

    @Override
    protected QueryParam getSoAutoConfigOfCondition() {
        return new Q().eq("type", COMPLETE);
    }

    @Override
    protected int getPendingListTotalBySoAutoConfigPO(QueryParam soQ) {
        return soMapper.count(soQ);
    }

    @Override
    protected List<SoPO> getPendingListBySoAutoConfigPO(QueryParam soQ) {
        return soMapper.list(soQ);
    }

    @Override
    protected void doHandlePendingList(List<SoPO> pendingList) {
        if (CollectionUtils.isNotEmpty(pendingList)) {
            Set<String> orderCodes = pendingList.stream().map(SoPO::getOrderCode).collect(Collectors.toSet());

            // 排除非结束的售后单（结束的售后单包括，审核不通过/验货不通过/已关闭/已完成）
            List<String> returnPendingOrders = soReturnMapper.list(new Q("orderCode")
                    .in("orderCode", orderCodes)
                    .neq("returnStatus", ReturnConstant.RETURN_STATUS_AUDIT_REJECT)
                    .neq("returnStatus", ReturnConstant.RETURN_STATUS_CHECK_REJECT)
                    .neq("returnStatus", ReturnConstant.RETURN_STATUS_CLOSED)
                    .neq("returnStatus", ReturnConstant.RETURN_STATUS_COMPLETED))
                    .stream()
                    .map(SoReturnPO::getOrderCode)
                    .collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(returnPendingOrders)) {
                orderCodes.removeAll(returnPendingOrders);
            }

            if (CollectionUtils.isNotEmpty(orderCodes)) {
                logger.info("准备自动完成订单：" + JSONObject.toJSONString(orderCodes));
                orderStatusService.updateByCodeListWithTx(OrderStatus.COMPLETED, ImmutableList.copyOf(orderCodes));
            }
        }
    }

    @Override
    protected Function<SoAutoConfigPO, String> getGroupByOfConditionAboutMerchant() {
        return po -> po.getMerchantId() + "_" + getGroupByOfCondition().apply(po);
    }

    @Override
    protected Function<SoAutoConfigPO, String> getGroupByOfCondition() {
        return po -> po.getOrderSource() + "_" + po.getPaymentType();
    }

    @Override
    protected QueryParam getPendingListOfCondition(SoAutoConfigPO po) {

        Calendar nowTime = Calendar.getInstance();
        nowTime.add(Calendar.MINUTE, Integer.valueOf(po.getTriggerAfterMinutes()) * -1);
        Date subTime = nowTime.getTime();

        QueryParam soQ = new Q("id", "orderCode", "storeId")
                .withSkipNullValueFilter(true)
                .eq("orderStatus", po.getOrderTriggerStatus())
                .eq("orderSource", po.getOrderSource()) // 交易方式
                .eq("orderPaymentType", po.getPaymentType())  // 付款方式
                .lt("orderReceiveDate", subTime);//订单收货时间

        return soQ;
    }
}
