package com.odianyun.oms.backend.task.order.job.handle.template.impl;

import com.alibaba.fastjson.JSON;
import com.odianyun.common.utils.log.LogUtils;
import com.odianyun.db.mybatis.QueryParam;
import com.odianyun.exception.factory.OdyExceptionFactory;
import com.odianyun.oms.backend.order.constants.ReturnConstant;
import com.odianyun.oms.backend.order.mapper.SoReturnMapper;
import com.odianyun.oms.backend.order.model.po.SoAutoConfigPO;
import com.odianyun.oms.backend.order.model.po.SoReturnPO;
import com.odianyun.oms.backend.order.service.SoReturnService;
import com.odianyun.oms.backend.task.order.job.handle.template.AbstractSoAutoTriggerHandler;
import com.odianyun.project.component.lock.IProjectLock;
import com.odianyun.project.support.base.db.Q;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

/**
 * @ClassName SoAutoReturnAuditHandler
 * @Description 处理订单售后自动审核
 * @Author 林涵
 * @Date 2021/4/19 15:53
 * @Version 1.0
 **/
@Component
public class SoAutoReturnAuditHandler extends AbstractSoAutoTriggerHandler<SoReturnPO> {

    private final Logger logger = LogUtils.getLogger(this.getClass());

    @Resource
    private SoReturnService soReturnService;
    @Resource
    private SoReturnMapper soReturnMapper;
    @Resource
    private IProjectLock projectLock;


    @Override
    protected QueryParam getSoAutoConfigOfCondition() {
        return new Q().eq("type", RETURN_AUDIT);
    }

    @Override
    protected int getPendingListTotalBySoAutoConfigPO(QueryParam soQ) {
        return soReturnMapper.count(soQ);
    }

    @Override
    protected List<SoReturnPO> getPendingListBySoAutoConfigPO(QueryParam soQ) {
        return soReturnMapper.list(soQ);
    }

    @Override
    protected void doHandlePendingList(List<SoReturnPO> pendingList) {
        if (CollectionUtils.isNotEmpty(pendingList)) {
            for (SoReturnPO srp : pendingList) {
                if (ReturnConstant.RETURN_TYPE_RR.equals(srp.getType()) || ReturnConstant.RETURN_TYPE_RE.equals(srp.getType())) {
                    srp.setIsPickUp(1);
                } else {
                    srp.setIsPickUp(0);
                }
                logger.info("准备自动审核售后单：" + JSON.toJSONString(srp));
                try {
                    projectLock.lock(srp.getOrderCode());
                    soReturnService.auditReturnPassedWithTx(srp);
                } catch (Exception e) {
                    OdyExceptionFactory.log(e);

                    // 某个售后单自动审核失败不影响其他售后单
                    logger.error("售后单[" + srp.getReturnCode() + "]自动审核失败", e);
                } finally {
                    projectLock.unlock(srp.getOrderCode());
                }
            }
        }
    }

    @Override
    protected Function<SoAutoConfigPO, String> getGroupByOfConditionAboutMerchant() {
        return po -> po.getMerchantId() + "_" + getGroupByOfCondition().apply(po);
    }

    @Override
    protected Function<SoAutoConfigPO, String> getGroupByOfCondition() {
        return po -> po.getReturnType();
    }

    @Override
    protected QueryParam getPendingListOfCondition(SoAutoConfigPO po) {

        Calendar now1 = Calendar.getInstance();
        Calendar now2 = Calendar.getInstance();
        now1.add(Calendar.MINUTE, Integer.valueOf(po.getTriggerAfterMinutes()) * -1);
        Date subTime1 = now1.getTime();
        now2.add(Calendar.MONTH, -6);
        Date subTime2 = now2.getTime();

        QueryParam soQ = new Q("id", "orderCode", "returnCode", "type", "merchantId", "goodsReturnType", "storeId", "sysSource", "isPickUp")
                .withSkipNullValueFilter(true)
                .eq("type", po.getReturnType())
                .eq("returnStatus", ReturnConstant.RETURN_STATUS_TO_AUDIT)
                .lt("createTime", subTime1).gt("createTime", subTime2);

        return soQ;
    }
}
