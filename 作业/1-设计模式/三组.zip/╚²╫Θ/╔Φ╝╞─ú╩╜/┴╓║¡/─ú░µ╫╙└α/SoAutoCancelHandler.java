package com.odianyun.oms.backend.task.order.job.handle.template.impl;

import com.odianyun.common.utils.log.LogUtils;
import com.odianyun.db.mybatis.QueryParam;
import com.odianyun.oms.backend.order.constants.OrderStatus;
import com.odianyun.oms.backend.order.constants.SoConstant;
import com.odianyun.oms.backend.order.mapper.SoMapper;
import com.odianyun.oms.backend.order.model.dto.SoDTO;
import com.odianyun.oms.backend.order.model.po.SoAutoConfigPO;
import com.odianyun.oms.backend.order.model.po.SoPO;
import com.odianyun.oms.backend.order.service.MessageCenterManageService;
import com.odianyun.oms.backend.order.service.SoService;
import com.odianyun.oms.backend.task.order.job.handle.template.AbstractSoAutoTriggerHandler;
import com.odianyun.project.support.base.db.Q;
import com.odianyun.util.BeanUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

/**
 * @ClassName SoAutoSignHandler
 * @Description 处理订单自动取消
 * @Author 林涵
 * @Date 2021/4/19 15:53
 * @Version 1.0
 **/
@Component
public class SoAutoCancelHandler extends AbstractSoAutoTriggerHandler<SoPO> {

    private final Logger logger = LogUtils.getLogger(this.getClass());

    @Resource
    private SoMapper soMapper;
    @Resource
    private SoService soService;
    @Resource
    private MessageCenterManageService messageCenterManageService;

    @Override
    protected QueryParam getSoAutoConfigOfCondition() {
        return new Q().eq("type", CANCEL);
    }

    @Override
    protected int getPendingListTotalBySoAutoConfigPO(QueryParam soQ) {
        return soMapper.count(soQ);
    }

    @Override
    protected List<SoPO> getPendingListBySoAutoConfigPO(QueryParam soQ) {
        return soMapper.list(soQ);
    }

    @Override
    protected void doHandlePendingList(List<SoPO> pendingList) {
        if (CollectionUtils.isNotEmpty(pendingList)) {
            for (SoPO so : pendingList) {
                so = soService.getPO(new Q().eq("orderCode", so.getOrderCode()));
                logger.info("准备自动取消订单：" + so.getOrderCode());

                SoDTO dto = BeanUtils.copyProperties(so, SoDTO.class);
                dto.setOrderCsCancelReason(SoConstant.ORDER_TIMEOUT_REASON);
                dto.setOrderCancelReasonId(SoConstant.ORDER_SYSTEM_CANCEL);
                dto.setOrderStatus(OrderStatus.CLOSED.code);
                dto.setOrderCanceOperateType(SoConstant.ORDER_CANCEL_TYPE_SYS);

                soService.cancelOrderWithTx(dto, true, true);
                messageCenterManageService.pushMessage(so.getOrderCode());
            }
        }
    }

    @Override
    protected Function<SoAutoConfigPO, String> getGroupByOfConditionAboutMerchant() {
        return po -> po.getMerchantId() + "_" + getGroupByOfCondition().apply(po);
    }

    @Override
    protected Function<SoAutoConfigPO, String> getGroupByOfCondition() {
        return po -> po.getOrderSource() + "_" + po.getPaymentType();
    }

    @Override
    protected QueryParam getPendingListOfCondition(SoAutoConfigPO po) {

        Calendar nowTime = Calendar.getInstance();
        nowTime.add(Calendar.MINUTE, Integer.valueOf(po.getTriggerAfterMinutes()) * -1);
        Date subTime = nowTime.getTime();

        QueryParam soQ = new Q()
                .withSkipNullValueFilter(true)
                .eq("orderPaymentStatus", SoConstant.PAYMENT_STATUS_PREPAY) //订单支付状态，待支付
                .eq("isLeaf", 1) // 1是子订单 2是父订单
                .eq("orderStatus", OrderStatus.TO_PAY.code) //订单状态
                .eq("orderSource", po.getOrderSource()) // 交易方式
                .eq("orderPaymentType", po.getPaymentType())  // 付款方式
                .lt("createTime", subTime);//订单创建时间
        return soQ;
    }
}
