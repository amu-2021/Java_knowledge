package com.odianyun.oms.backend.task.order.job.handle.template.impl;

import com.alibaba.fastjson.JSONObject;
import com.odianyun.common.utils.log.LogUtils;
import com.odianyun.db.mybatis.QueryParam;
import com.odianyun.oms.backend.order.constants.OrderStatus;
import com.odianyun.oms.backend.order.mapper.SoMapper;
import com.odianyun.oms.backend.order.model.po.SoAutoConfigPO;
import com.odianyun.oms.backend.order.model.po.SoPO;
import com.odianyun.oms.backend.order.service.OrderStatusService;
import com.odianyun.oms.backend.task.order.job.handle.template.AbstractSoAutoTriggerHandler;
import com.odianyun.project.support.base.db.Q;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @ClassName SoAutoSignHandler
 * @Description 处理订单自动签收
 * @Author 林涵
 * @Date 2021/4/19 15:53
 * @Version 1.0
 **/
@Component
public class SoAutoSignHandler extends AbstractSoAutoTriggerHandler<SoPO> {

    private final Logger logger = LogUtils.getLogger(this.getClass());

    @Resource
    private OrderStatusService orderStatusService;

    @Resource
    private SoMapper soMapper;

    @Override
    protected QueryParam getSoAutoConfigOfCondition() {
        return new Q().eq("type", SIGN);
    }

    @Override
    protected int getPendingListTotalBySoAutoConfigPO(QueryParam soQ) {
        return soMapper.count(soQ);
    }

    @Override
    protected List<SoPO> getPendingListBySoAutoConfigPO(QueryParam soQ) {
        return soMapper.list(soQ);
    }

    @Override
    protected void doHandlePendingList(List<SoPO> pendingList) {
        if (CollectionUtils.isNotEmpty(pendingList)) {
            logger.info("准备自动签收订单：" + JSONObject.toJSONString(pendingList.stream().map(SoPO::getOrderCode).collect(Collectors.toList())));
            orderStatusService.updateByCodeListWithTx(OrderStatus.SIGNED, pendingList.stream().map(SoPO::getOrderCode).collect(Collectors.toList()));
        }
    }

    @Override
    protected Function<SoAutoConfigPO, String> getGroupByOfConditionAboutMerchant() {
        return po -> po.getMerchantId() + "_" + getGroupByOfCondition().apply(po);
    }

    @Override
    protected Function<SoAutoConfigPO, String> getGroupByOfCondition() {
        return po -> po.getOrderSource() + "_" + po.getPaymentType();
    }

    @Override
    protected QueryParam getPendingListOfCondition(SoAutoConfigPO po) {

        Calendar nowTime = Calendar.getInstance();
        nowTime.add(Calendar.MINUTE, Integer.valueOf(po.getTriggerAfterMinutes()) * -1);
        Date subTime = nowTime.getTime();

        QueryParam soQ = new Q("id", "orderCode", "storeId")
                .withSkipNullValueFilter(true)
                .eq("orderStatus", po.getOrderTriggerStatus())
                .lt("orderLogisticsTime", subTime)//订单出库时间
                .eq("orderSource", po.getOrderSource()) // 交易方式
                .eq("orderPaymentType", po.getPaymentType());  // 付款方式

        return soQ;
    }
}
